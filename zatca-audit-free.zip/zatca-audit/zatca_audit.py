#!/usr/bin/env python3
"""ZATCA e-invoice readiness audit engine (L1, offline, deterministic).

Dossier B direction 1: the audit is the trust-build deliverable - fixed price,
48h, written gap list. This engine checks a candidate invoice XML (or a
generator's output) against the KSA e-invoicing standard's core rules WITHOUT
any network call. It does NOT replace ZATCA's official validators; it finds
the gaps a consultant engineer would check first, in seconds, offline.

Usage:
  python3 zatca_audit.py <invoice.xml> [more.xml ...]
  python3 zatca_audit.py --selftest

Exit codes: 0 all checks pass, 1 failures found, 2 usage error.
Output: plain-text gap list (the audit report skeleton).
"""
import sys, re, os
from xml.etree import ElementTree as ET

NS = {
    'inv': 'urn:oasis:names:specification:ubl:schema:xsd:Invoice-2',
    'cbc': 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2',
    'cac': 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2',
    'ext': 'urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2',
}

def checks_for(tree, text, path):
    C = []
    def chk(ok, rule, msg):
        C.append((ok, rule, msg))
    root = tree.getroot()
    # 1. UTF-8 without BOM
    chk(not text.startswith(b'\xef\xbb\xbf'), 'ENC-01', 'File must be UTF-8 without BOM')
    # 2. Root element is cbc:Invoice in UBL invoice namespace
    chk(root.tag == '{%s}Invoice' % NS['inv'], 'UBL-01', 'Root must be Invoice in UBL 2.1 invoice namespace')
    # 3. UUID present and v4
    uuid = root.findtext('cbc:UUID', namespaces=NS)
    chk(bool(uuid and re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$', uuid, re.I)),
        'KSA-05', 'cbc:UUID must be present and a valid version-4 UUID')
    # 4. Issue date/time
    chk(root.findtext('cbc:IssueDate', namespaces=NS) is not None, 'BR-02', 'cbc:IssueDate required')
    # 5. Invoice type code: 388 (tax) or 383/381 (credit/debit)
    itc = root.findtext('cbc:InvoiceTypeCode', namespaces=NS)
    chk(itc in ('388', '381', '383'), 'KSA-02', 'InvoiceTypeCode must be 388 (tax), 381 (credit) or 383 (debit)')
    # 6. Currency SAR
    cur = root.findtext('cbc:DocumentCurrencyCode', namespaces=NS)
    chk(cur == 'SAR', 'KSA-24', 'DocumentCurrencyCode must be SAR')
    # 7. Seller + buyer required
    for tag, name in (('cac:AccountingSupplierParty', 'seller'), ('cac:AccountingCustomerParty', 'buyer')):
        chk(root.find(tag, NS) is not None, 'BR-07' if 'seller' in name else 'BR-08', f'{name} party required')
    # 8. VAT registration number of seller (KSA: 15-digit)
    vat = root.findtext('.//cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cbc:CompanyID', namespaces=NS)
    chk(bool(vat and re.match(r'^\d{15}$', vat)), 'KSA-17', 'Seller VAT number (CompanyID) must be 15 digits')
    # 9. QR code AdditionalDocumentReference
    qr = [d for d in root.findall('cac:AdditionalDocumentReference', NS) if d.findtext('cbc:ID', namespaces=NS) == 'QR']
    chk(len(qr) >= 1, 'KSA-10', 'QR code AdditionalDocumentReference (ID=QR) required')
    # 10. PIH (previous invoice hash)
    pih = [d for d in root.findall('cac:AdditionalDocumentReference', NS) if d.findtext('cbc:ID', namespaces=NS) == 'PIH']
    chk(len(pih) >= 1, 'KSA-11', 'PIH (hash of previous invoice) required for the hash chain')
    # 11. UBL extensions present (signature + QR live there)
    chk(root.find('ext:UBLExtensions', NS) is not None, 'KSA-08', 'ext:UBLExtensions (signature/QR block) required')
    # 12. At least one invoice line
    lines = root.findall('cac:InvoiceLine', NS)
    chk(len(lines) >= 1, 'BR-16', 'At least one InvoiceLine required')
    # 13. Line-net / tax-exclusive / tax-inclusive / payable arithmetic (2dp tolerance)
    def f2(x):
        try: return round(float(x), 2)
        except: return None
    line_sum = 0.0
    saw_net = False
    for ln in lines:
        net = f2(ln.findtext('cbc:LineExtensionAmount', namespaces=NS) or 'nan')
        if net is None: chk(False, 'BR-26', 'Every line needs LineExtensionAmount'); continue
        saw_net = True
        line_sum += net
    tax_excl = f2(root.findtext('cbc:TaxExclusiveAmount', namespaces=NS) or 'nan')
    tax_incl = f2(root.findtext('cbc:TaxInclusiveAmount', namespaces=NS) or 'nan')
    payable = f2(root.findtext('cbc:PayableAmount', namespaces=NS) or 'nan')
    if None not in (tax_excl, tax_incl, payable) and saw_net:
        chk(f2(tax_excl - line_sum) in (0.0, -0.0), 'BR-CO-10', f'Sum of lines ({line_sum}) must equal TaxExclusiveAmount ({tax_excl})')
        chk(f2(tax_incl - tax_excl) >= 0, 'BR-CO-13', 'TaxInclusiveAmount must be >= TaxExclusiveAmount')
        chk(f2(payable - tax_incl) in (0.0, -0.0), 'BR-CO-16', 'PayableAmount must equal TaxInclusiveAmount')
    # 14. 2-decimal rounding on amounts
    for tag, rule in (('cac:LineExtensionAmount','BR-DEC-13'),('cac:TaxExclusiveAmount','BR-DEC-14'),('cac:PayableAmount','BR-DEC-19')):
        for el in root.iter('{%s}%s' % (NS['cac'], tag.split(':')[1])):
            v = el.text or ''
            if '.' in v and len(v.split('.')[1]) != 2:
                chk(False, rule, f'{tag} must have exactly 2 decimal places (got "{v}")')
    # 15. Simplified invoice must carry buyer-less allowance check: if type 388, buyer address required
    if itc == '388':
        bp = root.find('.//cac:AccountingCustomerParty/cac:Party/cac:PostalAddress', NS)
        chk(bp is not None, 'KSA-45', 'Tax invoice (388) requires buyer postal address')
    return C

def audit(path):
    with open(path, 'rb') as f:
        raw = f.read()
    out = [f'== {os.path.basename(path)} ==']
    try:
        tree = ET.parse(path)
    except ET.ParseError as e:
        out.append(f'FAIL WFL-01 not well-formed XML: {e}')
        return out, [False]
    results = checks_for(tree, raw, path)
    for ok, rule, msg in results:
        out.append(f'{"PASS" if ok else "FAIL"} {rule} {msg}')
    return out, results

def selftest():
    # Minimal bad invoice: must trip multiple rules. Namespace declarations
    # must be present for ElementTree to parse it at all.
    bad = b'''<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
 xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
 xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
 xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2">
<cbc:UUID>not-a-uuid</cbc:UUID><cbc:IssueDate>2026-09-27</cbc:IssueDate>
<cbc:InvoiceTypeCode>999</cbc:InvoiceTypeCode><cbc:DocumentCurrencyCode>USD</cbc:DocumentCurrencyCode>
</Invoice>'''
    open('/tmp/zatca_bad.xml','wb').write(bad)
    lines1, res1 = audit('/tmp/zatca_bad.xml')
    fails1 = sum(1 for ok, _, _ in res1 if not ok)
    ok = fails1 >= 5
    print('\n'.join(lines1))
    print(f'selftest: bad invoice tripped {fails1} rules (expect >=5): {"PASS" if ok else "FAIL"}')
    return ok



def quote(path, hourly=180):
    """Audit -> client-facing gap report with price estimate (AR/EN header)."""
    lines, results = audit(path)
    fails = [(r, m) for ok, r, m in results if not ok]
    hours = 1.5 + 0.75 * len(fails)
    low, high = int(hours*hourly*0.8), int(hours*hourly*1.3)
    out = ['='*52,
           'ZATCA E-INVOICING READINESS - GAP REPORT / تقرير الجاهزية',
           '='*52,
           f'File: {os.path.basename(path)}',
           f'Checks run: {len(results)}   Passed: {len(results)-len(fails)}   Gaps: {len(fails)}',
           '']
    if fails:
        out.append('GAPS FOUND (fix these so every invoice goes through cleanly):')
        for r, m in fails:
            out.append(f'  - [{r}] {m}')
    else:
        out.append('NO GAPS FOUND - invoice structure passes the L1 rule set.')
    out += ['', 'FIX ESTIMATE',
            f'  Effort: ~{hours:.1f} hours',
            f'  Price range: SAR {low:,} - SAR {high:,}',
            '',
            'Next step: reply to this report and we schedule the 48h fix window.',
            '='*52]
    return '\n'.join(out)




import base64, hashlib

def tlv(tag, value):
    b = value.encode('utf-8')
    return bytes([tag, len(b)]) + b

def qr_payload(seller_name, vat_number, timestamp, total, vat_total):
    """ZATCA phase-2 TLV QR payload, base64 (tags 1-5)."""
    raw = (tlv(1, seller_name) + tlv(2, vat_number) + tlv(3, timestamp)
           + tlv(4, f'{total:.2f}') + tlv(5, f'{vat_total:.2f}'))
    return base64.b64encode(raw).decode()

def qr_selftest():
    # Known-shape check: decode our own payload back and verify fields round-trip.
    p = qr_payload('Cedar Dental', '300000000000003', '2026-09-27T21:30:00Z', 115.0, 15.0)
    dec = base64.b64decode(p)
    fields, i = {}, 0
    while i < len(dec):
        tag, ln = dec[i], dec[i+1]
        fields[tag] = dec[i+2:i+2+ln].decode('utf-8')
        i += 2 + ln
    ok = (fields[1]=='Cedar Dental' and fields[2]=='300000000000003'
          and fields[4]=='115.00' and fields[5]=='15.00')
    print(f'qr_selftest: round-trip {"PASS" if ok else "FAIL"} payload={p[:48]}...')
    return ok


def main(argv):
    if len(argv) < 2:
        print(__doc__); return 2
    if argv[1] == '--selftest':
        return 0 if selftest() else 1
    if argv[1] == '--qr-selftest':
        return 0 if qr_selftest() else 1
    if argv[1] == '--quote':
        print(quote(argv[2])); return 0
    all_ok = True
    for p in argv[1:]:
        lines, res = audit(p)
        print('\n'.join(lines))
        all_ok = all_ok and all(ok for ok, _, _ in res)
    return 0 if all_ok else 1

if __name__ == '__main__':
    sys.exit(main(sys.argv))
