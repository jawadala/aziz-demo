# ZATCA Invoice Readiness Audit (free mini-tool)
## فحص جاهزية الفاتورة الإلكترونية

Run / التشغيل:
    python3 zatca_audit.py your-invoice.xml

15 structural checks, offline, nothing leaves your machine.
فحوصات بنيوية، تعمل دون اتصال، ولا شيء يخرج من جهازك.

Exit 0 = clean. Exit 1 = gaps found (list printed).

Want the written report + fixed-price fix?
تريد التقرير المكتوب والإصلاح بسعر ثابت؟
https://jawadala.github.io/aziz-demo/zatca-readiness.html
